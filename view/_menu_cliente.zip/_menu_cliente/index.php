<?php
include './config/dt00.php';
include './config/cnxn.php';
include './model/_seguridad/seguridad.php';
$db = new Seguridad();
$e = $_SESSION['E'];
$u = $_SESSION['U'];
$cec = $_SESSION['CEC'];
$db->E = $e;
$db->U = $u;
$sServicios = $db->sMyServDisp($cec);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VIPG - CLIENTE</title>
    <link rel="stylesheet" href="view/css/materialize.min.css" media="screen,projection" />
    <link rel="stylesheet" href="view/css/general.css?5" media="screen,projection" />
    <link rel="stylesheet" href="view/css/_menu.css?5" media="screen,projection" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <script src="view/js/jquery.min.js?5"></script>
</head>

<body>

    <header>
        <nav class="blue-grey darken-3">
            <div class="nav-wrapper">
                <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons white-text">menu</i></a>
                <ul id="nav-mobile" class="right hide-on-med-and-down">
                    <li><a href="#" id="txt_username_nav" class="bold">---</a></li>
                    <li><a href="#" id="bt_salir_nv"><i class="material-icons white-text" title="Salir">exit_to_app</i></a></li>
                </ul>
            </div>
        </nav>
    
        <ul id="slide-out" class="sidenav sidenav-fixed blue-grey darken-3">
            <li class="lg-logo">
                <img src="view/img/general/logo2.png" width="154px" />
            </li>
            <li class="divider hide-on-large-only"></li>
            <li class="hide-on-large-only"><a href="#!" id="txt_username_menu" class="truncate bold center">-</a></li>
            <li class="divider"></li>
            <?php if($sServicios != false){foreach ($sServicios as $item) { ?>
            <li><a href="#!" class="collapsible-header waves-effect sidenav-close white-text" id="serv<?php echo $item[0]; ?>"><i class="material-icons blue-text">fact_check</i><?php echo $item[1]; ?></a></li>
            <?php }} ?>
            <li><a href="http://consultas.funcionjudicial.gob.ec/informacionjudicial/public/informacion.jsf" class="collapsible-header waves-effect sidenav-close white-text" target="_blank"><i class="material-icons blue-text">fact_check</i>Función Judicial</a></li>
            <li><a href="https://supa.funcionjudicial.gob.ec/pensiones/publico/consulta.jsf" class="collapsible-header waves-effect sidenav-close white-text" target="_blank"><i class="material-icons blue-text">fact_check</i>SUPA</a></li>
            <li><a href="https://www.fiscalia.gob.ec/consulta-de-noticias-del-delito/" class="collapsible-header waves-effect sidenav-close white-text" target="_blank"><i class="material-icons blue-text">fact_check</i>Fiscalia</a></li>
            <li><a href="https://certificados.ministeriodelinterior.gob.ec/gestorcertificados/antecedentes/" class="collapsible-header waves-effect sidenav-close white-text" target="_blank" id="bt_funju"><i class="material-icons blue-text">fact_check</i>Antecedentes Penales</a></li>
            <li><a href="https://www.interpol.int/es/Como-trabajamos/Notificaciones/Notificaciones-rojas/Ver-las-notificaciones-rojas" class="collapsible-header waves-effect sidenav-close white-text" target="_blank" id="bt_funju"><i class="material-icons blue-text">fact_check</i>Interpol</a></li>

            <li><a href="#!" class="collapsible-header waves-effect sidenav-close white-text" id="parai"><i class="material-icons blue-text">fact_check</i>Paraísos fiscales</a></li>
            <li><a href="#!" class="collapsible-header waves-effect sidenav-close white-text" id="bt_ccont"><i class="material-icons yellow-text">lock</i>Cambiar contraseña</a></li>
            <li><a href="#!" class="collapsible-header waves-effect white-text" id="bt_salir"><i class="material-icons red-text">exit_to_app</i>Salir</a></li>
            <li><span class="white-text"></span></li>
            <li><span class="white-text"></span></li>
        </ul>
    </header>

    <div id="dv_here" class="grey-text text-lighten-1"></div>

    <main id="res"></main>

    <script type="text/javascript" src="view/js/materialize.min.js"></script>
    <script src="view/js/_s005.js?5"></script>
    <script src="view/js/_menu_cliente.js?5"></script>
</body>

</html>